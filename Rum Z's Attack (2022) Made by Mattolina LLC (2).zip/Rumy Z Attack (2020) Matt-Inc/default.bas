 playfield:
 ..XXXXXXXXXXXXXXXXXXXXXX........
 ...XXXXXXXXXXXXXXXXXXXXX........
 ......XXXXXXXXXXXXXXXXX.........
 .............XXXXXXXX...........
 ............XXXXXXXX............
 ...........XXXXXXXX.............
 ..........XXXXXXXXX.............
 .........XXXXX...XX.............
 .X.......XXXXXXXXXX.............
 ..X.......XXXXXXXX..............
 ...X..XXX..XXXXX................
end
 COLUBK = $80
 COLUPF = $C0
 player0x=50:player0y=50
 player1x=20:player1y=20
 missile0height=4:missile0y=255
 NUSIZ0 = 16

sprites
 player0:
 %01010000
 %11111000
 %11110000
 %01101000
 %10010000
 %11001000
 %01111000
 %00110000 
end
 
 player1:
 %01000001
 %00100010
 %00011100
 %11101011
 %10001001
 %00011100
 %00010100
 %00011100 
end
 if missile0y>240 then goto skip
 missile0y = missile0y-2:goto draw_loop
skip
 if joy0fire then missile0y = player0y-2:missile0x=player0x+4
draw_loop
 drawscreen
 if player1y < player0y then player1y = player1y+1
 if player1y>player0y then player1y = player1y-1
 if player1x< player0x then player1x = player1x+1
 if player1x> player0x then player1x = player1x-1
 player1x = player1x:player1y = player1y
  if joy0up then player0y = player0y-1: goto jump
 if joy0down then player0y = player0y+1: goto jump
 if joy0left then player0x = player0x-1: goto jump
 if joy0right then player0x = player0x+1: goto jump
jump
 goto sprites




 





































 



 









